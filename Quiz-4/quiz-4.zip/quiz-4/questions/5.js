/**
 * Function to get all domains
 * - should return a promise
 *   error message: "No items matching ${vin}"
 * @param {*} data - see shape in ../../data.example.json
 * @returns Array of strings, eg ["gmail.com", "yahoo.com"]
 */
const getEmailDomains = (data) => {};
module.exports = getEmailDomains;
